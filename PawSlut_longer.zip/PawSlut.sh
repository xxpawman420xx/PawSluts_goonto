#!/bin/sh
payload=$(find ~/ -type f -name "goonto-windows.exe")
loop () {
time1=$(shuf -i 600-3600 -n 1)
sleep $time1
konsole -e nohup wine $payload &
PID1=$!
sleep 1
kill $PID1
time2=$(shuf -i 1200-7200 -n 1)
sleep $time2
PID2=goonto-windows.exe
pkill -f $PID2
}
while true
do
   loop
done
